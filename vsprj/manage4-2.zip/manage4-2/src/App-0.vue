<template>
  <div>
    <div> 
      <router-link to="/">首页</router-link>
      <router-link to="/user">用户管理</router-link>
    </div>
    <router-view></router-view>
  </div>
</template>

<script setup>
</script>

<style lang="less" scoped>

</style>