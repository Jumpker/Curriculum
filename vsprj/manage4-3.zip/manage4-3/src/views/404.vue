<template>
    <div>
        oops,页面不存在！
    </div>
</template>

<script setup>
</script>

<style lang="less" scoped>

</style>