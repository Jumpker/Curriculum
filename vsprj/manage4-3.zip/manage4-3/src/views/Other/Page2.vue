<template>
    <div>
        page2
    </div>
</template>

<script setup>
</script>

<style lang="less" scoped>

</style>